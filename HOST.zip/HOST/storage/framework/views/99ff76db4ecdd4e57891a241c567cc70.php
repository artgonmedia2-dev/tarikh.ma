<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-6 py-16">
    <section class="text-center mb-16">
        <h1 class="text-4xl md:text-6xl font-black mb-6 text-slate-900 dark:text-white">
            L'histoire du Royaume <span class="text-primary italic">à portée de clic</span>
        </h1>
        <p class="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto mb-10">
            Tarikh.ma centralise les archives numériques du patrimoine historique marocain. Consultation en ligne uniquement.
        </p>
        <a href="<?php echo e(route('documents.index')); ?>" class="inline-block bg-primary text-slate-900 px-8 py-4 rounded-xl font-bold hover:brightness-110 transition-all">
            Explorer les archives
        </a>
    </section>

    <?php if($recentDocuments->isNotEmpty()): ?>
    <section>
        <h2 class="text-2xl font-bold mb-6">Documents récents</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $recentDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('documents.show', $doc)); ?>" class="block p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-primary transition-colors">
                <span class="text-xs font-bold text-primary uppercase"><?php echo e($doc->type); ?></span>
                <h3 class="font-bold mt-1 line-clamp-2"><?php echo e($doc->title); ?></h3>
                <p class="text-sm text-slate-500 mt-1"><?php echo e($doc->views_count); ?> vues</p>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\TARIKH.MA\tarikh.ma\tarikh-ma-laravel\resources\views/home.blade.php ENDPATH**/ ?>