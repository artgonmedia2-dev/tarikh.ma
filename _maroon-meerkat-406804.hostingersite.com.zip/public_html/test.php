<?php
echo "PHP is working on this server.\n";
echo "Current Time: " . date('Y-m-d H:i:s') . "\n";
echo "Host: " . $_SERVER['HTTP_HOST'] . "\n";
?>
