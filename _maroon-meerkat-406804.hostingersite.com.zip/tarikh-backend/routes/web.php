<?php

use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\DocumentController as AdminDocumentController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\File;

// Public API (Géré par React, on laisse Laravel gérer uniquement le stream si besoin)
// Route::get('/', [HomeController::class, 'index'])->name('home');
// Route::get('/a-propos', [HomeController::class, 'about'])->name('about');
// Route::get('/archives', [DocumentController::class, 'index'])->name('documents.index');
// Route::get('/documents/{document}', [DocumentController::class, 'show'])->name('documents.show');
Route::get('/documents/{document}/stream', [DocumentController::class, 'stream'])->name('documents.stream');

// Admin (auth + role admin|editor)
Route::middleware(['auth', 'role:admin,editor'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminDashboardController::class, 'index'])->name('dashboard');
    Route::resource('documents', AdminDocumentController::class)->except(['show']);
});

Route::middleware(['auth', 'role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::resource('users', AdminUserController::class);
});

// Route de secours pour éviter le crash "Route [login] not defined"
Route::get('/login', function () {
    return redirect('/');
})->name('login');

if (file_exists(__DIR__ . '/auth.php')) {
    require __DIR__ . '/auth.php';
}

// Fallback : Rediriger vers React index.html
Route::fallback(function () {
    $path = public_path('index.html');
    if (File::exists($path)) {
        return File::get($path);
    }
    return abort(404);
});
